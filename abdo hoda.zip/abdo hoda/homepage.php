 <?php
  $connect=mysqli_connect('localhost','root','','goodreads');
session_start();
if (isset($_SESSION['handle'])) {
$bookauthor=addslashes($_SESSION['handle']);
$authorcur="SELECT Fname,NumberOfBooks,facebook,twitter,ProfileImage,linkedin FROM author  WHERE Handle='$bookauthor'";
$result=mysqli_query($connect,$authorcur);
$myauthor=mysqli_fetch_all($result,MYSQLI_ASSOC);
$img=$myauthor[0]['ProfileImage'];
$name=$myauthor[0]['Fname'];
$face=$myauthor[0]['facebook'];
$linked=$myauthor[0]['linkedin'];
$twitter=$myauthor[0]['twitter'];
$NumberOfBooks=$myauthor[0]['NumberOfBooks'];
$other="SELECT Fname,NumberOfBooks,ProfileImage FROM author WHERE Handle !='$bookauthor' ";
$result=mysqli_query($connect,$other);
$otherauthor=mysqli_fetch_all($result,MYSQLI_ASSOC);
$type='AUTHORS';

}
else{
    //$_SESSION['Username']='@abdoa';
    $user=addslashes($_SESSION['Username']);
    
$usercur="SELECT Fname,NumberOfBooks,facebookacc,twitteracc,Image,linkedinacc FROM users  WHERE Username='$user'";
$result=mysqli_query($connect,$usercur);
$myuser=mysqli_fetch_assoc($result);
$img=$myuser['Image'];
$name=$myuser['Fname'];
$face=$myuser['facebookacc'];
$linked=$myuser['linkedinacc'];
$twitter=$myuser['twitteracc'];
$NumberOfBooks=$myuser['NumberOfBooks'];
$others="SELECT Fname,NumberOfBooks,Image FROM users WHERE Username !='$user' ";
$result=mysqli_query($connect,$others);
$otherauthor=mysqli_fetch_all($result,MYSQLI_ASSOC);
//print_r($otheruser);
$type='USERS';

}
//$sql1="SELECT bookImage, title, price,Fname FROM book,author  WHERE BookAuthor = '$bookauthor' and Handle='$bookauthor'";
$sql1="SELECT bookImage, title, price,Fname FROM book,author  WHERE  Handle=BookAuthor";
$result=mysqli_query($connect,$sql1);
$abook=mysqli_fetch_all($result,MYSQLI_ASSOC);

// $other="SELECT Fname,NumberOfBooks,ProfileImage FROM author WHERE Handle !='$bookauthor' ";
// $result=mysqli_query($connect,$other);
// $otherauthor=mysqli_fetch_all($result,MYSQLI_ASSOC);
#print_r($otherauthor);
?>
 <!DOCTYPE html>
 <html lang="en">

 <head>
     <meta charset="UTF-8">
     <meta http-equiv="X-UA-Compatible" content="IE=edge">
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
     <title>Document</title>
     <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet"
         integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
     <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css"
         integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous" />
     <link rel="stylesheet" href="../Footer/footerStyle.css">
     <link rel="stylesheet" href="../WebsiteHeader/2headerStyle.css">
     <!-- <link rel="stylesheet" href="../Adham/formStyle.css"> -->
     <link rel="stylesheet" href="homepage.css">
     <style>
     /* .navbar-dark .navbar-nav .nav-link:focus,
    .navbar-dark .navbar-nav .nav-link:hover {
        color: rgb(255 255 255);
    } */
     </style>
 </head>

 <body>
     <?php include '../WebsiteHeader/2header.php' ?>
     <div class=" landing  d-flex justify-content-center align-items-start abi">
         <div class="abb">
             <img src="../images/<?php echo htmlspecialchars($img); ?>" class="img-fluid abimg" alt="Cinque Terre"
                 width="200px" height="200px">
             <h3><?php echo htmlspecialchars($name); ?></h3>
             <p class="no-of-books"><?php echo htmlspecialchars($NumberOfBooks); ?> Books</p>
             <!-- <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Dicta consequuntur pariatur, odio obcaecati
                 hic
                 et ipsa nisi sed voluptates fugit perferendis cupiditate deleniti voluptatum ad consequatur, dolorum
                 libero. Ea molestias accusamus ut
                 cum provident doloribus repudiandae corporis, qui excepturi at.</p> -->
             <div class="social-container row justify-content-center">
                 <a href="<?php echo htmlspecialchars($face); ?>" class="social col-3 fc"><i
                         class="fab fa-facebook-f"></i></a>
                 <a href="<?php echo htmlspecialchars($linked); ?>" class="social col-3 in"><i
                         class="fab fa-linkedin-in"></i>
                     <a href="<?php echo htmlspecialchars($twitter); ?>" class="social col-3 tw"><i
                             class="fab fa-twitter"></i></a>
             </div>
         </div>
     </div>
     <div class="author-works mb-2 ">
         <h3 class="text-center black py-4 ">All Books</h3>
     </div>

     </div>
     <div class="container">
         <div class="books row d-flex justify-content-center ">
             <?php foreach($abook as $i){ ?>
             <div class="col-sm-5 col-md-4 col-lg-2 book row justify-content-center ">
                 <img src="../images/<?php echo htmlspecialchars($i['bookImage']); ?>" class="img-fluid abimg"
                     alt="Cinque Terre" width="200px" height="200px">
                 <div class="pra row justify-content-center">
                     <div class="speech">
                         <p class="title"><?php echo htmlspecialchars($i['title']); ?></p>
                         <p class="author-name"><?php echo htmlspecialchars($i['Fname']); ?></p>
                         <p class="price"><?php echo htmlspecialchars($i['price']); ?>$</p>
                     </div>
                 </div>
             </div>
             <?php } ?>

         </div>
     </div>
     <div class="vaa py-5 bg-light">
         <div class="container   ">
             <p class="cf text-center">VIEW ANOTHER <?php echo $type; ?></p>

             <div class="row d-flex justify-content-center">
                 <?php foreach($otherauthor as $i){ ?>
                 <div class="col-sm-5 col-md-4 col-lg-2 book row justify-content-center m2">

                     <img src="../images/<?php echo (isset($_SESSION['handle']))?$i['ProfileImage']:$i['Image']; ?>"
                         alt="" class="img-fluid abimg lio " width="50px" height="50px">
                     <div class="inform my-2 text-center">
                         <h4 class="author-name"><?php echo htmlspecialchars($i['Fname']); ?></h4>
                         <p class="number-of-books"><?php echo htmlspecialchars($i['NumberOfBooks']); ?> book</p>
                         <a href="" class="viewprofile">VIEW PROFILE</a>
                     </div>

                 </div>
                 <?php } ?>

             </div>
         </div>
     </div>
     </div>
     <!-- js link -->
     <?php include '../Footer/footer.php' ?>

 </body>