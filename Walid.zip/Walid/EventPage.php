<?php
include 'SigningEvent.php'
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous" />
    <link rel="stylesheet" href="../Footer/footerStyle.css">
    <link rel="stylesheet" href="../WebsiteHeader/2headerStyle.css">
    <link rel="stylesheet" href="rating.css">
    <style>
        .btn-outline-secondary {
            color: #1b8bcb;
            border-color: #1b8bcb;
        }

        .btn-outline-secondary:hover {
            color: #fff;
            background-color: #1b8bcb;
            border-color: #1b8bcb;
        }

        .navbar-dark .navbar-nav .nav-link:focus,
        .navbar-dark .navbar-nav .nav-link:hover {
            color: rgb(255 255 255);
        }
    </style>
</head>

<body>
    <?php include '../WebsiteHeader/2header.php' ?>
    <div class="fluid bg-light mb-4">
        <?php foreach ($eventData as $event) { ?>
        <div id="data" class="container d-sm-flex justify-content-around align-items-center flex-row-reverse">
            <div class="container bg-light d-flex justify-content-center ">
                <img src="../images/book1.jpeg" class="m-2" alt="No Image Available">
            </div>
            <div class="container bg-light">
                <div class="card bg-light" style="border:0px solid black">
                    <div class="card-body">
                        <h1 class="card-title"><?php echo $event['Title']; ?></h1>
                        <!-- <h5 class="card-subtitle mb-2 text-muted"></h5> -->
                        <p class="card-text" style="font-size: 1.08rem!important; margin-bottom:3px">Event ID <b><?php echo $event['ID']; ?></b> </p>
                        <p class="card-text" style="font-size: 1.08rem!important; margin-bottom:3px">Author <b><?php echo $event['Fname']?> 
                        <?php echo $event['Minit']?>  <?php echo $event['Lname']?> </b> </p>
                        <p class="card-text" style="font-size: 1.08rem!important; margin-bottom:3px">Book to be Signed <b><?php echo $event['title']?></b> </p>
                        <!-- <p class="card-text" style="font-size: 1.08rem!important; margin-bottom:3px"> Publish Date <b><?php echo $data['Pubdate'] ?></b> </p> -->
                        <a href="#" class="card-link">Author</a>
                    </div>
                </div>
            </div>
        </div>
        <?php } ?>
    </div>
</body>